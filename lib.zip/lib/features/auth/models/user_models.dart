class User {
  final String? name;
  final String? email;
  final String? password;

  User({this.name, this.email, this.password});
}
