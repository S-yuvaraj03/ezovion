abstract class LoginRepo {
  Future<bool> login(String email, String password);
}
