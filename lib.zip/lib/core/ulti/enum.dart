enum SnackBarType { success, error }
