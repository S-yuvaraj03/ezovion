abstract class Usecase {}
