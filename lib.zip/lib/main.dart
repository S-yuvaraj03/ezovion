import 'package:ezovian/core/theme/apptheme.dart';
import 'package:ezovian/features/auth/bloc/auth_bloc.dart';
import 'package:ezovian/features/auth/repository.dart/auth_repository.dart';
import 'package:ezovian/core/ulti/routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return RepositoryProvider(
      create: (_) => AuthRepository(),
      child: BlocProvider(
        create: (context) => AuthBloc(context.read<AuthRepository>()),
        child: MaterialApp(
          title: 'Ezovian Test App',
          theme: AppTheme.lightTheme,
          initialRoute: AppRoutes.login,
          routes: AppRoutes.routes,
        ),
      ),
    );
  }
}
